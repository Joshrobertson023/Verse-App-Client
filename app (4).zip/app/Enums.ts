    enum Status {
        Active,
        Inactive,
        Deleted,
    }

    export default Status;