const colors = {
    primaryWhite: '#EAE9FC',
    transparent: 'transparent',
    error: 'red'
}

export default colors;