import { Stack } from 'expo-router';
import React from 'react';
import { PaperProvider } from 'react-native-paper';
import useAppTheme from './theme';

export default function RootLayout() {
  const theme = useAppTheme();
  return ( 
      <PaperProvider theme={theme}>
        <Stack>
          <Stack.Screen 
            name="(auth)"
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="(tabs)"
            options={{ headerShown: false }} 
          />
          <Stack.Screen 
            name="collections/addnew"
            options={{ 
              title: 'New Collection',
              headerStyle: {
                backgroundColor: theme.colors.background,
              },
              headerTitleStyle: {
                color: theme.colors.onBackground,
              },
              headerTintColor: theme.colors.primary,
             }} 
          />
          <Stack.Screen
            name="notifications"
            options={{
              title: 'Notifications',
              headerStyle: {
                backgroundColor: theme.colors.background,
              },
              headerTitleStyle: {
                color: theme.colors.onBackground,
              },
              headerTintColor: theme.colors.primary,
            }}
          />
          <Stack.Screen 
            name="collections/[id]"
            options={{
              title: '',
              headerStyle: {
                backgroundColor: theme.colors.background,
              },
              headerTitleStyle: {
                color: theme.colors.onBackground,
              },
              headerTintColor: theme.colors.primary,
            }} 
          />
          <Stack.Screen
          name="user/profile"
          options={{
            title: 'Profile',
            headerStyle: {
              backgroundColor: theme.colors.background,
            },
            headerTitleStyle: {
              color: theme.colors.onBackground,
            },
            headerTintColor: theme.colors.primary,
          }}
          />
        </Stack>
      </PaperProvider>
  )
}